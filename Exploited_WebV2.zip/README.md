## ParEntropy

Our game for the **Global Game Jam 2019** (made in less than 48hours and fixed a bit afterwards).


Play as Dominique, an overwhelmed parent, and try to save the house from entropy and mayhem the longest you can ! Then try again and beat your score !!

Click on the events in the house and win the mini-game with multiple one actives for more score, or let it go and get closer to the end. Risky decisions shall be rewarded. 
The rest of the controls are indicated in game. Make sure to play whith the sound enabled ;)

P.S. : you may need more than 2 arms ;) (solo parenting is hard)




### Credits

**Game designers and developpers :** Pyrofoux, Guillaume GROSSE, HugzFnr

**Music and sound designer :** Roxane Pilot

**2D Lead Artist :** Mael NUBLAT

**More about the project :** https://globalgamejam.org/2019/games/parentropy


### Demonstration

You can play it directly on your bowser on this link : https://hugzfnr.github.io/GGJ19-Kazoo-All-Devs/

But if you are a bit lost, here is a 2 minute-ish long video demonstration of the game that I commented in french and might help you : https://youtu.be/ctcIIJ-dBVg

One day I shall subtitle it in english, promised.

